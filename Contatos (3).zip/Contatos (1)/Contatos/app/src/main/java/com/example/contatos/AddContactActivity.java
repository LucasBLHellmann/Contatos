package com.example.contatos;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.UUID;

public class AddContactActivity extends AppCompatActivity {

    private EditText etName, etPhone;
    private Spinner spPhoneType;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        spPhoneType = findViewById(R.id.spPhoneType);
        Button btnSave = findViewById(R.id.btnSave);

        db = FirebaseFirestore.getInstance();

        btnSave.setOnClickListener(v -> saveContact());
    }

    private void saveContact() {
        String id = UUID.randomUUID().toString();
        String name = etName.getText().toString();
        String phone = etPhone.getText().toString();
        String phoneType = spPhoneType.getSelectedItem().toString();

        if (name.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        Contact contact = new Contact(id, name, phone, phoneType);
        db.collection("contacts").document(id).set(contact)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Contato salvo", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Erro ao salvar", Toast.LENGTH_SHORT).show());
    }
}

