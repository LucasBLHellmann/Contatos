package com.example.contatos;

public class Contact {
    private String id;
    private String name;
    private String phone;
    private String phoneType;

    // Construtor vazio necessário para Firestore
    public Contact() {}

    public Contact(String id, String name, String phone, String phoneType) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.phoneType = phoneType;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public String getPhoneType() { return phoneType; }
}
