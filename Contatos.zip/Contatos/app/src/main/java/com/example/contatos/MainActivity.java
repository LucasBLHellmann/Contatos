package com.example.contacts;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contatos.AddContactActivity;
import com.example.contatos.Contact;
import com.example.contatos.ContactAdapter;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ContactAdapter adapter;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.rvContacts);
        Button btnAddContact = findViewById(R.id.btnAddContact);

        db = FirebaseFirestore.getInstance();
        adapter = new ContactAdapter(new ArrayList<>());

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnAddContact.setOnClickListener(v -> openAddContactActivity());

        loadContacts();
    }

    private void loadContacts() {
        db.collection("contacts").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                List<Contact> contacts = new ArrayList<>();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Contact contact = document.toObject(Contact.class);
                    contacts.add(contact);
                }
                adapter.updateContacts(contacts);
            } else {
                Toast.makeText(this, "Erro ao carregar contatos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openAddContactActivity() {
        startActivity(new Intent(this, AddContactActivity.class));
    }
}

